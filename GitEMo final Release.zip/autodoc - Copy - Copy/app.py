import os
from flask import Flask, request, jsonify, render_template




from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
import pandas as pd 
import numpy as np
import re
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nrclex import NRCLex

def process_url(url):
    response = request.get_json(url)
    # Add your custom processing logic here, e.g., extracting specific data, running calculations, etc.
    
# Download required NLTK datasets
    nltk.download('punkt')
    nltk.download('stopwords')
    nltk.download('wordnet')
    nltk.download('omw-1.4')

    # Define the list of stopwords and WordNetLemmatizer
    stopwords = nltk.corpus.stopwords.words('english')
    wn = nltk.WordNetLemmatizer()

    # Define a function to clean the text
    def clean_text(text):
        # Remove non-alphabetic characters
        text = re.sub('[^a-zA-Z]', ' ', text)
        # Convert to lowercase
        text = text.lower()
        # Tokenize the text
        text = nltk.word_tokenize(text)
        # Lemmatize the words and remove stopwords
        text = [wn.lemmatize(word) for word in text if word not in stopwords]
        # Join the words back into a string
        text = ' '.join(text)
        return text

    # Define a function to get the sentiment scores and attach emojis
    def get_sentiment_scores(text):
        text_object = NRCLex(text)
        # Get the sentiment scores
        sentiment_scores = text_object.affect_frequencies
        # Define the emojis for each sentiment category
        emojis = {'anger': '😠', 'anticip': '🤔', 'anticipation': '🤔', 'disgust': '🤢', 'fear': '😨', 'joy':'😇', 'positive': '😊', 'negative': '😔', 'sadness':'😔', 'surprise': '😮', 'trust': '😇'}
        # Attach the appropriate emoji to each sentiment score
        sentiment_scores_emojis = {emojis[sentiment_category]: score for sentiment_category, score in sentiment_scores.items()}
        print(sentiment_scores_emojis)
        return sentiment_scores_emojis

    #url = 'https://github.com/tensorflow/tensorflow/pull/60409'

    driver = webdriver.Chrome()
    driver.get(url)

    comments = driver.find_elements(By.CLASS_NAME,"comment-body")

    comment_texts = [element.text for element in comments]
    i=0
    for cmnts in comment_texts:
        print(i,cmnts)
        print()
        i=i+1

    
    sendarr= []
    for element in comments:
        # Apply the clean_text function to the 'Comment'
        Clean_text = clean_text(element.text)
        # Apply the get_sentiment_scores function to the 'clean_text' column
        sentiment_scores = get_sentiment_scores(Clean_text)
        sendarr.append(sentiment_scores)
        


    
    # For this example, we'll just return the status code and content length
    result = {
        'response': response,
        'scores':sendarr
    
        
        
    }
    return result


app = Flask(__name__)


@app.route('/process_url', methods=['POST'])
def handle_process_url():
    data = request.get_json()
    url = data.get('url')
    
    if not url:
        return jsonify({'error': 'URL parameter is required'}), 400

    try:
        result = process_url(url)
        return jsonify({'result': result})
    except Exception as e:
        return jsonify({'error e': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 8080)))
