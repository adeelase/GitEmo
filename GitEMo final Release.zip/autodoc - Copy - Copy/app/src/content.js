




let receiver = (message,sender,sendResponse)=>{
    console.log("received message",message)
    init(message);
    sendResponse({received:"message recieved"})
}



chrome.runtime.onMessage.addListener(receiver)




//injector inject after receving message 
const init = function(message){
    const elements = document.getElementsByClassName('timeline-comment-header');
    
const textToAdd = message;
    console.log(message)

for (let i = 0; i < elements.length; i++) {
    // Create a new text node with the desired text

    let maxKey = null;
    let maxValue = -Infinity;

    Object.entries(textToAdd[i]).forEach(([key, value]) => {
    if (value > maxValue) {
        maxValue = value;
        maxKey = key;
    }
    });



    const textNode = document.createTextNode(maxKey);

    // Append the text node to the current element (div)
    elements[i].appendChild(textNode);

    // If you want to add the text on a new line, you can create a <br> element and append it as well
    const lineBreak = document.createElement('br');
    elements[i].appendChild(lineBreak);
}

}


