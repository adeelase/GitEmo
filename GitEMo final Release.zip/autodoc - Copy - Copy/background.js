
chrome.runtime.onInstalled.addListener(function() {
    
    chrome.contextMenus.create({
        "id":"test",
        "title":"Generate Documentation",
        "contexts":["all"]
    })
   })
   

let sendMessage = (info,tab)=>{
    

    async function getCurrentTabUrl () {
        const tabs = await chrome.tabs.query({ active: true })

        console.log(tabs[0].url)
        return tabs[0].url
      }

    async function postData(url = "", data = {}) {
        // Default options are marked with *
        const response = await fetch(url, {
          method: "POST", // *GET, POST, PUT, DELETE, etc.
          mode: "cors", // no-cors, *cors, same-origin
          cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
          credentials: "same-origin", // include, *same-origin, omit
          headers: {
            "Content-Type": "application/json",
            // 'Content-Type': 'application/x-www-form-urlencoded',
          },
          redirect: "follow", // manual, *follow, error
          referrerPolicy: "no-referrer", // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
          body: JSON.stringify(data), // body data type must match "Content-Type" header
        });
        return response.json(); // parses JSON response into native JavaScript objects
      }
      
      tabs = getCurrentTabUrl()
      
      tabs.then(value=>{
        console.log(value)
        postData("http://localhost:8080/process_url", { url: value }).then((data) => {
            console.log(data); // JSON data parsed by `data.json()` call
            chrome.tabs.sendMessage(tab.id,data.result.scores,()=>{
                console.log("message sent")
            })
          });
      }).catch(err => {
        console.log(err);
        });
     
      
    


    
    console.log(tab);
    
}

chrome.contextMenus.onClicked.addListener(
    (info,tab)=>{
        sendMessage(info,tab)
    }
  )
// contexts should be selection s


